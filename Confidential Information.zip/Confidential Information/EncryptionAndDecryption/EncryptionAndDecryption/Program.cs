﻿//Developer Credits:
//Program implement by Tshepo Mayaba
//DO NOT COPY! Coding is art


string decryptedMsg = Decryption("Kvu'a qbknl h ivvr if paz jvcly", 7);
string encryptedMsg = Encryption(decryptedMsg, 7);

Console.WriteLine($"Encrypted Message: {encryptedMsg}");
Console.WriteLine($"Decrypted Message: {decryptedMsg}");


string Encryption(string message, int key)
{
	string output = null;
	foreach (char c in message)
	{
		if (char.IsLetter(c))
		{
			char character = ConvertCharacter(c);
			char shiftedChar = ShiftCharacter(c, key, character);
			output += shiftedChar;
		}
		else
			output += c;
	}
	return output;
}
string Decryption(string message, int key)
{
	return Encryption(message, 26 - key);
}

char ConvertCharacter(char character)
{
	return char.IsLower(character) ? 'a' : 'A';
}
char ShiftCharacter(char character, int key, char convertedCharacter)
{
	return (char)((((character + key) - convertedCharacter) % 26) + convertedCharacter);
}


